"""Páginas exibidas no stacked widget da janela principal."""

from .login_page import LoginPage
from .dashboard_page import DashboardPage

__all__ = ["LoginPage", "DashboardPage"]


